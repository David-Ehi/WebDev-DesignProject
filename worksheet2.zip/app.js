// load express
const express = require('express');
// load handlebars
const exphbs = require('express-handlebars');

// instantiate express
const app = express();

// configure express to use handlebars as templating engine
app.engine(
  'hbs',
  exphbs.engine({
    extname: '.hbs',
    // use this layout by default - if you have different layout
    // for say home page - you can toggle this in your code
    defaultLayout: 'default',
    // set location of layouts
    layoutsDir: 'views/layouts',
    // set location of partials - header, footer, etc
    partialsDir: 'views/partials',
  })
);
// set the view engine to handlesbards
app.set('view engine', 'hbs');
// where to find all of the view
app.set('views',  'views');
// where to find static files - css, images, js
app.use(express.static('public'));

// home page or home route
app.get('/', (req, res) => {

  // set active or not for navigation
    state={home : true, contact : false, thewii : false}
  // set specifics for <head>
  head={title: "The Switch", description:"This is all the info on the Switch", keywords: "Nintendo, swith, console"}
  res.render('index', {state:state, head:head});
  // send this to terminal where node app is running
  console.log('home')

});

app.get('/theds', (req, res) => {
    state={home : false, theds : true, thewii : false}
    head={title: "The Ds", description:"This is all the info on the Ds", keywords: "Nintendo, Ds, console"}
    res.render('theds', { state:state, head:head});
    console.log('theds')
  });

app.get('/thewii', (req, res) => {
    state={home : false, theds : false, thewii : true}
    head={title: "The Wii", description:"This is all the info on the Wii", keywords: "Nintendo, Wii, console"}
    res.render('thewii', { state:state, head:head});
    console.log('thewii')
  });

  app.get('/thegameboy', (req, res) => {
    state={home : false, theds : false, thewii : false, thegameboy : true}
    head={title: "The GameBoy", description:"This is all the info on the gameboy", keywords: "Nintendo, Gameboy, console"}
    res.render('thegameboy', { state:state, head:head});
    console.log('thegameboy')
  });

    app.get('/thankyou', (req, res) => {
    state={home : false, theds : false, thewii : false, thegameboy : false,}
    head={title: "Thank You", description:"this is the thank you page", keywords: "thank you"}
    res.render('thankyou', { state:state, head:head});
    console.log('thankyou')
  });

app.get('/thankyou', (req, res) => {
const { name, email, message } = req.query;
state = { thankyou: true };
head = { title: "Thank You - Week 1" };
res.render('thankyou', {state, head, name, email, message});

console.log('thankyou', req.query);
});

// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});